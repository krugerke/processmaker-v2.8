<?php
 $ERROR_TEXT = "404 Not Found ";
 $ERROR_DESCRIPTION = "
      Your browser (or proxy) sent a request
      that this server could not understand.<br />
      <br />
      <strong>Possible reasons: </strong><br />
      Your link is broken. This may occur when you receive
      a link via email, but your client software adds line breaks, thus distorting
      long URLs. <br />
      <br />
      The page you requested is no longer active. <br />
      <br />
      There is a typographic
      error in the link, in case you entered the URL into the browser's address
      toolbar.<br />
      <br />
  ";

 include ( "header.php");
?>
