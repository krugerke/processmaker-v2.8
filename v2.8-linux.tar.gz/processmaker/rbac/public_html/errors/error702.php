<?php
 $ERROR_TEXT = "702 workspace undefined   ";
 $ERROR_DESCRIPTION = "You have specified an undefined workspace. <br>
      Please review your URL and try it again.<br />
      <br />
  ";
  
 include ( "header.php");
?>