<?php

  $pro['datasources']['forum']['connection'] = 'mysql://forum:colosa123@mysql3.colosa.net/forum';
  $pro['datasources']['forum']['adapter'] = 'mysql';

  $pro['datasources']['bugs']['connection'] = 'mysql://forum:colosa123@mysql3.colosa.net/bugs';
  $pro['datasources']['bugs']['adapter'] = 'mysql';
  return $pro;
?>
